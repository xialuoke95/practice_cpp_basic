var searchData=
[
  ['s',['s',['../unionapr__descriptor.html#a39a15be8be084afadfa173810b346f6c',1,'apr_descriptor']]],
  ['s_5faddr',['s_addr',['../structin__addr.html#a1bf09b20f0531edf5da627f712561108',1,'in_addr']]],
  ['sa',['sa',['../structapr__sockaddr__t.html#a3ca40eae640100e0f157e7c21b33a17d',1,'apr_sockaddr_t']]],
  ['salen',['salen',['../structapr__sockaddr__t.html#aef1d2a482f85eeab7b6bf0a7732a087a',1,'apr_sockaddr_t']]],
  ['servname',['servname',['../structapr__sockaddr__t.html#a668335161a8347b9a34c600bff80b52f',1,'apr_sockaddr_t']]],
  ['sin',['sin',['../structapr__sockaddr__t.html#a7d5cf0290260c3c448360fc819b28714',1,'apr_sockaddr_t']]],
  ['size',['size',['../structapr__finfo__t.html#a3e47a673c5b82a25a783a732dee6f946',1,'apr_finfo_t::size()'],['../structapr__mmap__t.html#a274aea0906a4b674e1642ac9e81966c7',1,'apr_mmap_t::size()']]],
  ['skip_5fend',['skip_end',['../structapr__getopt__t.html#ae9e7e6eb1576820c7dc6e589cc3a28b7',1,'apr_getopt_t']]],
  ['skip_5fstart',['skip_start',['../structapr__getopt__t.html#a0cd41eedf9ed82bf5d9dcc3491ee67dd',1,'apr_getopt_t']]]
];
