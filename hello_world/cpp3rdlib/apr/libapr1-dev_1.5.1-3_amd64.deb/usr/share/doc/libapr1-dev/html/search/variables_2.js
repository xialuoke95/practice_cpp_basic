var searchData=
[
  ['desc',['desc',['../structapr__pollfd__t.html#ad63baa71bb91f80513d33482e28fb967',1,'apr_pollfd_t']]],
  ['desc_5ftype',['desc_type',['../structapr__pollfd__t.html#acfafd260241a874745f49ba2df246c53',1,'apr_pollfd_t']]],
  ['description',['description',['../structapr__getopt__option__t.html#a8fd515c0a9e621f6c0d058772429ab98',1,'apr_getopt_option_t']]],
  ['device',['device',['../structapr__finfo__t.html#a38cbfbff641284065481f5907d59c8bf',1,'apr_finfo_t']]]
];
