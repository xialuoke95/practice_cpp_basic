var searchData=
[
  ['random_20functions',['Random Functions',['../group__apr__random.html',1,'']]],
  ['ring_20macro_20implementations',['Ring Macro Implementations',['../group__apr__ring.html',1,'']]],
  ['reader_2fwriter_20lock_20routines',['Reader/Writer Lock Routines',['../group__apr__thread__rwlock.html',1,'']]],
  ['ref',['ref',['../structapr__memnode__t.html#ac68a939c0c3d48498ec0c0fde409c502',1,'apr_memnode_t']]],
  ['remote',['remote',['../structapr__os__sock__info__t.html#ae71fe14a5eb9141fc4ad0a6d0a91f17e',1,'apr_os_sock_info_t']]],
  ['reqevents',['reqevents',['../structapr__pollfd__t.html#abcedac7097a97823a38ece6e47f4ea9f',1,'apr_pollfd_t']]],
  ['reset',['reset',['../structapr__getopt__t.html#abc4e72bc761666c0b0d9015c3b0de8c3',1,'apr_getopt_t']]],
  ['rtnevents',['rtnevents',['../structapr__pollfd__t.html#aed5b2109b27984975309922bfa84e3f6',1,'apr_pollfd_t']]]
];
