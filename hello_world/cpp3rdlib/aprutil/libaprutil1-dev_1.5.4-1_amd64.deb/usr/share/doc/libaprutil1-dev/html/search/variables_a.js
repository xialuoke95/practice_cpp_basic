var searchData=
[
  ['mmap',['mmap',['../structapr__bucket__mmap.html#a66e9385752aaacb7fef7e96db62f1920',1,'apr_bucket_mmap::mmap()'],['../unionapr__bucket__structs.html#a627c4ca697f06bbf4226c8c2acd93cbc',1,'apr_bucket_structs::mmap()']]]
];
