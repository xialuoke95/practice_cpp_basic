var searchData=
[
  ['crypto_20routines',['Crypto routines',['../group___a_p_r___util___crypto.html',1,'']]],
  ['can_5fmmap',['can_mmap',['../structapr__bucket__file.html#a7812a8d6e6f10d0095569f04d3423e83',1,'apr_bucket_file']]],
  ['check_5fconn',['check_conn',['../structapr__dbd__driver__t.html#a93567b4557c0bf19c3ce104fb4636f46',1,'apr_dbd_driver_t']]],
  ['close',['close',['../structapr__dbd__driver__t.html#aef39417149ae8af2738bd8aaa92bcb42',1,'apr_dbd_driver_t::close()'],['../structapr__dbm__type__t.html#a21e4c81ee578b14ef5503c5ac7ee9312',1,'apr_dbm_type_t::close()']]],
  ['cmd_5fget',['cmd_get',['../structapr__memcache__stats__t.html#abd9b0fa7bf554436883c8b6a2a89c2a8',1,'apr_memcache_stats_t']]],
  ['cmd_5fset',['cmd_set',['../structapr__memcache__stats__t.html#a4930557b41d879b1b4767862c1693f95',1,'apr_memcache_stats_t']]],
  ['compare',['compare',['../structapr__strmatch__pattern.html#a722ba7f187cc179ac5fe0b306b8f9624',1,'apr_strmatch_pattern']]],
  ['connection_5fstructures',['connection_structures',['../structapr__memcache__stats__t.html#ac155c7a510e94b3cd43aea90a05e3cd3',1,'apr_memcache_stats_t']]],
  ['conns',['conns',['../structapr__memcache__server__t.html#a49f27525b9dd7de3dfb15dba3b86bd05',1,'apr_memcache_server_t']]],
  ['context',['context',['../structapr__strmatch__pattern.html#a0e74c401e8825e462e202175bf033a9c',1,'apr_strmatch_pattern']]],
  ['copy',['copy',['../structapr__bucket__type__t.html#a300d6b15d55a3a1f13eeec7379100c38',1,'apr_bucket_type_t']]],
  ['count',['count',['../structapr__md4__ctx__t.html#a0332072316c6a931b6fb1bd8729e3495',1,'apr_md4_ctx_t::count()'],['../structapr__md5__ctx__t.html#a3234a76e68a4ef546026a9854f9ba6d0',1,'apr_md5_ctx_t::count()']]],
  ['count_5flo',['count_lo',['../structapr__sha1__ctx__t.html#ab105efa48b9318a419525e0f6076f6d2',1,'apr_sha1_ctx_t']]],
  ['curr_5fconnections',['curr_connections',['../structapr__memcache__stats__t.html#a1db1876674d978f4f70ae465a060bfc2',1,'apr_memcache_stats_t']]],
  ['curr_5fitems',['curr_items',['../structapr__memcache__stats__t.html#abe0f28297441a55d30a6c7c8e0faaea3',1,'apr_memcache_stats_t']]]
];
