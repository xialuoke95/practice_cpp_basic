var searchData=
[
  ['query',['query',['../structapr__uri__t.html#a88d889bcda9e95696022f04ffb470678',1,'apr_uri_t::query()'],['../structapr__dbd__driver__t.html#a87de2303419493ddab5b0c1a298c9837',1,'apr_dbd_driver_t::query()']]]
];
